(() => {
  // 한 번만 초기화
  if (window.videoRecorderInitialized) return;
  window.videoRecorderInitialized = true;

  let recorder = null;
  let uploadWorker = null;
  let workerUrl = null;
  let part = 0;
  const pendingUploads = [];
  let onVideoEnded = null;

  // 해상도별 설정 매핑
  const configMap = {
    '1080p':   { vBps:  8000000, aBps: 128000, fps: 30 },
    '1080p60': { vBps: 12000000, aBps: 192000, fps: 60 },
    '1440p':   { vBps: 20000000, aBps: 192000, fps: 30 },
    '1440p60': { vBps: 30000000, aBps: 192000, fps: 60 },
    '4k':      { vBps: 40000000, aBps: 256000, fps: 30 },
    '4k60':    { vBps: 60000000, aBps: 320000, fps: 60 }
  };

  // iframe 내부에서 <video> 요소 찾기
  function findVideoInIframes() {
    const iframes = Array.from(document.querySelectorAll('iframe'));
    for (const iframe of iframes) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow.document;
        const vid = doc.querySelector('video');
        if (vid) return vid;
      } catch (e) {
        console.warn('⚠️ iframe 접근 불가:', e);
      }
    }
    return null;
  }

  // 업로드용 워커 생성
  function createUploadWorker() {
    const code = `
      self.onmessage = async function(e) {
        const { chunk, part } = e.data;
        try {
          const res = await fetch(
            'http://localhost:5000/upload?part=' + part,
            {
              method: 'POST',
              mode: 'cors',
              headers: { 'Content-Type': 'video/webm' },
              body: chunk
            }
          );
          self.postMessage({ part, status: res.status });
        } catch (err) {
          self.postMessage({ part, error: err.message });
        }
      };
    `;
    const blob = new Blob([code], { type: 'application/javascript' });
    workerUrl = URL.createObjectURL(blob);
    return new Worker(workerUrl);
  }

  // 녹화 시작
  function startRecording(resolution, chunkInterval) {
    let video = document.querySelector('video');
    if (!video) {
      console.log('👀 페이지에 <video> 없어서 iframe 검색...');
      video = findVideoInIframes();
    }
    if (!video) {
      alert('❌ <video> 요소를 찾을 수 없습니다.');
      return;
    }

    const { vBps, aBps, fps } = configMap[resolution] || configMap['1080p'];

    // 비디오 재생 종료 시 자동 중지 핸들러
    onVideoEnded = () => {
      console.log('▶️ 비디오 재생 종료 감지, 녹화 중지');
      stopRecording();
    };
    video.addEventListener('ended', onVideoEnded);

    // 업로드 워커 초기화
    uploadWorker = createUploadWorker();
    uploadWorker.onmessage = e => console.log('[upload-worker]', e.data);

    const stream = video.captureStream(fps);
    if (!stream || !stream.getTracks().length) {
      alert('⚠️ 비디오 스트림을 가져올 수 없습니다.');
      video.removeEventListener('ended', onVideoEnded);
      return;
    }

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
      ? 'video/webm;codecs=vp9,opus'
      : 'video/webm;codecs=vp8,opus';

    recorder = new MediaRecorder(stream, {
      mimeType,
      videoBitsPerSecond: vBps,
      audioBitsPerSecond: aBps
    });

    recorder.ondataavailable = e => {
      if (!e.data || e.data.size === 0) return;
      const currentPart = part++;
      const uploadPromise = new Promise((resolve, reject) => {
        function handler(ev) {
          if (ev.data.part !== currentPart) return;
          ev.data.error ? reject(ev.data.error) : resolve(ev.data.status);
          uploadWorker.removeEventListener('message', handler);
        }
        uploadWorker.addEventListener('message', handler);
      });
      pendingUploads.push(uploadPromise);
      uploadWorker.postMessage({ chunk: e.data, part: currentPart });
    };

    recorder.onstop = () => {
      console.log('🎬 녹화 종료 – 업로드 대기 중...');
      video.removeEventListener('ended', onVideoEnded);

      Promise.all(pendingUploads)
        .then(() => fetch('http://localhost:5000/merge', { method: 'POST', mode: 'cors' }))
        .then(r => console.log('🧩 병합 응답:', r.status))
        .catch(err => console.error('⚠️ 병합 실패:', err))
        .finally(() => {
          uploadWorker.terminate();
          URL.revokeObjectURL(workerUrl);
          console.log('🛑 워커 종료');
          // 상태 초기화
          part = 0;
          pendingUploads.length = 0;
        });
    };

    recorder.start(chunkInterval);
    console.log(`🔴 녹화 시작 (${resolution}, ${fps}fps, vBps=${vBps}, interval=${chunkInterval}ms)`);
  }

  // 녹화 중지
  function stopRecording() {
    if (recorder && recorder.state === 'recording') {
      recorder.stop();
      console.log('⏹ 녹화 중지 요청');
    } else {
      alert('❌ 녹화가 실행 중이 아닙니다.');
    }
  }

  // popup.js에서 보낸 메시지 수신
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'START') {
      startRecording(msg.resolution, msg.chunkInterval);
      sendResponse({ result: 'started' });
    } else if (msg.action === 'STOP') {
      stopRecording();
      sendResponse({ result: 'stopped' });
    }
    return false;
  });
})();