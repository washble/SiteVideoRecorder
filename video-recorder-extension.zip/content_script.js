(() => {
  // 한 번만 초기화
  if (window.videoRecorderInitialized) return;
  window.videoRecorderInitialized = true;

  let recorder = null;
  let chunks   = [];

  // 해상도별 설정 매핑
  const configMap = {
    '1080p':   { vBps:  8000000, aBps: 128000, fps: 30 },
    '1080p60': { vBps: 12000000, aBps: 192000, fps: 60 },
    '1440p':   { vBps: 20000000, aBps: 192000, fps: 30 },
    '1440p60': { vBps: 30000000, aBps: 192000, fps: 60 },
    '4k':      { vBps: 40000000, aBps: 256000, fps: 30 },
    '4k60':    { vBps: 60000000, aBps: 320000, fps: 60 }
  };

  // iframe 내부에서 <video> 요소 찾기
  function findVideoInIframes() {
    const iframes = Array.from(document.querySelectorAll('iframe'));
    for (const iframe of iframes) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow.document;
        const vid = doc.querySelector('video');
        if (vid) return vid;
      } catch (e) {
        console.warn('⚠️ iframe 접근 불가:', e);
      }
    }
    return null;
  }

  // 녹화 시작
  function startRecording(resolution, chunkInterval) {
    let video = document.querySelector('video');
    if (!video) {
      console.log('👀 페이지에 <video> 없어서 iframe 검색...');
      video = findVideoInIframes();
    }
    if (!video) {
      alert('❌ <video> 요소를 찾을 수 없습니다.');
      return;
    }

    const cfg    = configMap[resolution] || configMap['1080p'];
    const { vBps, aBps, fps } = cfg;
    const stream = video.captureStream(fps);

    if (!stream || !stream.getTracks().length) {
      alert('⚠️ 비디오 스트림을 가져올 수 없습니다.');
      return;
    }

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
      ? 'video/webm;codecs=vp9,opus'
      : 'video/webm;codecs=vp8,opus';

    recorder = new MediaRecorder(stream, {
      mimeType,
      videoBitsPerSecond: vBps,
      audioBitsPerSecond: aBps
    });
    chunks = [];

    recorder.ondataavailable = e => {
      if (e.data && e.data.size) chunks.push(e.data);
    };

    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `recorded_${resolution}.webm`;
      a.click();
      setTimeout(() => {
        URL.revokeObjectURL(url);
        console.log('🎬 녹화 완료 및 다운로드');
      }, 300);
    };

    recorder.start(chunkInterval);
    console.log(`🔴 녹화 시작 (${resolution}, ${fps}fps, vBps=${vBps}, interval=${chunkInterval})`);
  }

  // 녹화 중지
  function stopRecording() {
    if (recorder && recorder.state === 'recording') {
      recorder.stop();
      console.log('⏹ 녹화 중지 요청');
    } else {
      alert('❌ 녹화가 실행 중이 아닙니다.');
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'START') {
      startRecording(msg.resolution, msg.chunkInterval);
      sendResponse({ result: 'started' });
    } else if (msg.action === 'STOP') {
      stopRecording();
      sendResponse({ result: 'stopped' });
    }
    return false;
  });
})();