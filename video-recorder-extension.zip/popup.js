const startBtn      = document.getElementById('start');
const stopBtn       = document.getElementById('stop');
const selRes        = document.getElementById('resolution');
const chunkInterval = document.getElementById('chunkInterval');

// 팝업 열릴 때 이전 선택값 불러오기
document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(['resolution', 'chunkInterval'], (result) => {
    if (result.resolution) {
      selRes.value = result.resolution;
    }
    if (result.chunkInterval) {
      chunkInterval.value = result.chunkInterval;
    }
  });
});

// 설정 변경 시 저장
selRes.addEventListener('change', () => {
  chrome.storage.local.set({ resolution: selRes.value });
});
chunkInterval.addEventListener('input', () => {
  chrome.storage.local.set({ chunkInterval: chunkInterval.value });
});

async function sendMessageWithInjection(tabId, message, callback) {
  chrome.tabs.sendMessage(tabId, message, (response) => {
    if (chrome.runtime.lastError) {
      chrome.scripting.executeScript({
        target: { tabId },
        files: ['content_script.js']
      }, () => {
        chrome.tabs.sendMessage(tabId, message, callback);
      });
    } else {
      callback(response);
    }
  });
}

startBtn.addEventListener('click', async () => {
  const resolution = selRes.value;
  const interval   = parseInt(chunkInterval.value, 10) || 1000;
  const [tab]      = await chrome.tabs.query({ active: true, currentWindow: true });

  sendMessageWithInjection(
    tab.id,
    { action: 'START', resolution, chunkInterval: interval },
    (resp) => console.log('START 응답:', resp)
  );
});

stopBtn.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  sendMessageWithInjection(
    tab.id,
    { action: 'STOP' },
    (resp) => console.log('STOP 응답:', resp)
  );
});